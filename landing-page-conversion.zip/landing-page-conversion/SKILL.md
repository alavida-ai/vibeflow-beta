---
name: landing-page-conversion
description: Create high-converting landing pages using evidence-based best practices from industry research. This skill should be used when designing or optimizing landing pages, generating landing page copy, or applying conversion optimization principles. Includes comprehensive guide synthesized from 3 authoritative sources (Unbounce, Mailchimp) and workflow for generating brand-aligned landing page copy.
---

# Landing Page Conversion

## Overview

This skill provides evidence-based guidance for creating high-converting landing pages and a structured workflow for generating brand-aligned landing page copy. Based on research synthesizing insights from 3 authoritative sources analyzing 15 landing pages with 30-77% conversion rates.

**Key capabilities:**
- Apply proven conversion principles (6.6% average → 30%+ high-performing)
- Generate brand-aligned landing page copy following systematic workflow
- Reference comprehensive best practices guide covering structure, copy, design, and technical optimization
- Align landing page elements with Vibeflow's brand strategy and voice

## When to Use This Skill

Use this skill when:
- **Creating new landing pages** - Apply conversion principles from the start
- **Optimizing existing landing pages** - Audit against best practices checklist
- **Generating landing page copy** - Follow workflow for brand-aligned messaging
- **A/B testing** - Identify high-impact elements to test
- **Campaign planning** - Ensure message match from ad to landing page
- **Conversion rate optimization** - Systematically improve performance

## Core Conversion Principles

Apply these **9 non-negotiable requirements** (universal consensus from all sources) to every landing page:

1. **Single focused conversion goal** - One primary CTA, no competing actions
2. **Benefits over features** - Show transformation, not specifications
3. **Clear, compelling CTAs** - Descriptive, action-oriented, visually prominent
4. **Remove navigation/distractions** - Eliminate exit paths before conversion
5. **Product shown in context** - Demonstrate use, make benefits tangible
6. **Authentic social proof** - Real testimonials with names, photos, details
7. **Mobile optimization** - Responsive design for 83% of traffic
8. **Page speed under 3 seconds** - Critical for preventing abandonment
9. **A/B testing mindset** - Continuous experimentation drives improvement

## Key Benchmarks to Know

- **Average conversion rate:** 6.6% (baseline)
- **High-performing threshold:** 30%+ conversion
- **Elite tier:** 60%+ conversion (rare)
- **Mobile traffic:** 83% of all visits
- **Video impact:** Up to 80% conversion increase
- **Load time threshold:** Under 3 seconds

## Workflow: Generate Brand-Aligned Landing Page Copy

Follow this systematic 6-phase workflow to create landing page copy that combines conversion best practices with Vibeflow's brand strategy.

### Phase 1: Load Brand Context

**Step 1:** Read core brand strategy documents to understand positioning, voice, and messaging:
- `/brand/strategy/brand-fundamentals/STRATEGY.md` - Brand pillars and purpose
- `/brand/strategy/positioning/STRATEGY.md` - Marketing Architecture category positioning
- `/brand/strategy/voice/STRATEGY.md` - Voice attributes and tone
- `/brand/strategy/messaging/STRATEGY.md` - Core value propositions
- `/brand/strategy/audience/STRATEGY.md` - Target audience profile

**Step 2:** Reference landing page conversion principles from `references/landing-page-guide.md`

**Extract key constraints:**
- Never use "easy," "effortless," "simple"
- Never create vendor lock-in
- Never position AI as replacement
- Never target "all marketers"
- Never prioritize volume over quality

### Phase 2: Define Landing Page Goals

Clarify these before generating copy:

**Conversion objective:** What single action should visitors take?
- Sign up for early access
- Book a demo
- Download resource
- Start free trial
- Join waitlist

**Target segment:** Which Marketing Architects specifically?
- Agency owners scaling operations
- Solo consultants seeking efficiency
- In-house leaders building capabilities
- Technical marketers embracing AI

**Message match context:** Where is traffic coming from?
- Paid ads (match ad copy)
- Organic search (match search intent)
- Email campaigns (maintain consistency)
- Social media posts (align with post content)

### Phase 3: Generate Landing Page Sections

**Headline Formula:** [Problem solved] + [for whom] + [differentiator]

**Vibeflow-specific considerations:**
- Use power verbs: "Build," "Own," "Architect," "Design," "Master"
- Lead with capability, not convenience
- Target ambitious 5-10%, not "all marketers"
- Apply voice: 90% straightforward, 85% serious, 70% respectful

**Example framework:**
> Build [outcome] You Own—Not Rent [alternative competitor offers]

**Sections to generate:**
1. **Headline** - Core value in 5 seconds
2. **Subheadline** - Supporting detail expanding promise
3. **Hero CTA** - Descriptive action (not "Get Started")
4. **Value Proposition** - 3-5 benefit bullets
5. **Social Proof** - Authentic testimonials with details
6. **Features/Benefits Grid** - What you get → What it enables
7. **Trust Signals** - Logos, stats, credibility indicators
8. **Secondary CTA** - Reframed call to action

### Phase 4: Apply Conversion Optimization

**Message Match Check:**
- Headline echoes ad/source copy
- Keywords consistent
- Visual theme aligned
- Promise delivered

**Conversion Principle Audit:**
- Single focused goal (one primary CTA)
- Benefits emphasized over features
- Clear, descriptive CTA copy
- Navigation removed
- Authentic social proof
- Mobile-responsive considerations

**Voice Consistency Check:**
- Technically credible without jargon
- Intellectually provocative
- Ownership-focused ("own," "build," "architect")
- Evidence-based (specific outcomes)
- Systems-builder mindset

**Constraint Compliance:**
- No "easy/effortless/simple" language
- No vendor lock-in positioning
- No AI-as-replacement framing
- No "all marketers" targeting
- No volume-over-quality messaging

### Phase 5: Refine and Iterate

**Simplify for scannability:**
- Short paragraphs (2-3 sentences max)
- Bullet points for lists
- Subheadings breaking content
- Bold key phrases

**Strengthen benefits:**
- Ask "So what?" for each feature
- Transform feature → benefit statements
- Emphasize transformation outcomes

**Progressive disclosure:**
- Above fold: Headline + value prop + CTA (fast-track)
- Below fold: Education for skeptics (how it works, proof)
- Bottom: FAQ, secondary CTA, final trust signals

### Phase 6: Format for Delivery

Organize output with these sections:

```
# Landing Page: [Title]

## Hero Section
- Headline
- Subheadline
- CTA copy

## Value Proposition
- 3-5 benefit bullets

## Social Proof
- Testimonial(s) with authentic details

## Features/Benefits Grid
- Table format: What you get | What it enables

## Trust Signals
- Logos, stats, credibility indicators

## Secondary CTA
- Reframed call to action

## Implementation Notes
- Design suggestions
- Voice rationale
- A/B testing recommendations
```

## Quick Conversion Checklist

Before finalizing any landing page:
- [ ] Single focused conversion goal
- [ ] Benefits-oriented headline
- [ ] Clear, descriptive CTA above fold
- [ ] Navigation/competing links removed
- [ ] Product shown in context
- [ ] Authentic social proof with details
- [ ] Mobile-optimized design
- [ ] Load time under 3 seconds
- [ ] A/B testing plan in place

## Resources

### references/landing-page-guide.md

Comprehensive guide covering:
- Core conversion principles with evidence
- Structural elements (above-the-fold, visual hierarchy, white space)
- Copy & messaging best practices (headlines, scannable text, progressive disclosure)
- Visual & design guidelines (product in context, video impact, contrasting CTAs)
- Technical optimization (load speed, mobile, forms, A/B testing)
- Trust & credibility signals (social proof, authentic testimonials)
- Landing page type variations (lead gen, click-through, ecommerce, B2B vs B2C)
- Common mistakes to avoid
- Case study highlights (12 examples with 30-77% conversion rates)
- Quantitative benchmarks

**When to reference:** Load this when needing detailed best practices, specific examples, or quantitative benchmarks.

### workflows/generate-landing-page-copy.md

Complete step-by-step workflow with:
- Phase 1: Load Brand Context
- Phase 2: Define Landing Page Goals
- Phase 3: Generate Landing Page Sections
- Phase 4: Apply Conversion Optimization
- Phase 5: Refine and Iterate
- Phase 6: Format for Delivery

**When to reference:** Follow this workflow when generating new landing page copy from scratch to ensure brand alignment and conversion optimization.

## Integration with Brand Strategy

**Brand Pillars to Emphasize:**
1. **Capability Over Convenience** - Avoid "easy" language, position complexity as moat
2. **Own Your Stack, Own Your Destiny** - Use ownership language ("own," "control," "build")
3. **Architect Systems, Don't Rent Automation** - Position as transformation to Marketing Architect
4. **Enhance Humans, Don't Replace Them** - Frame AI as leverage, not replacement
5. **Quality Through Craft** - Emphasize quality outcomes, not volume metrics

**Voice Attributes to Apply:**
- **Technically credible** - Use concrete specifics, no jargon
- **Intellectually provocative** - Challenge conventional thinking
- **Ownership-focused** - Reinforce infrastructure ownership
- **Evidence-based** - Include concrete data, citations
- **Systems-builder** - Emphasize workflow design, long-term leverage

## Common Landing Page Types

**Lead Generation (Form Completion):**
- Multi-step forms reduce friction
- Privacy policies required
- Higher trust requirements
- Average conversion: Lower than 6.6%

**Click-Through (Simple Action):**
- Minimal friction design
- Focus on pre-purchase education
- Clear expectation-setting
- Average conversion: Higher than 6.6%

**Ecommerce Product:**
- Strong visual component required
- Benefits-oriented copy essential
- Fast load times critical
- Average conversion: 4.2%

**B2B vs B2C:**
- B2B: Longer cycles, more proof points, higher detail tolerance
- B2C: Faster decisions, emotional triggers, shorter attention spans

## A/B Testing Recommendations

**High-impact elements to test:**
- Headline variations (benefit vs transformation focus)
- CTA copy (action-oriented vs outcome-oriented)
- Social proof placement (above vs below features)
- Form length (if lead gen)
- Video presence (80% conversion potential)
- Hero image (product context variations)

**Testing philosophy:** Make data-driven decisions, not gut-instinct decisions. Keep testing even successful pages to understand and compound wins.

---

**For complete research details and case studies:** See `/brand/research/landing-page-best-practices/2025-10-31@15:57/RESEARCH.md`
